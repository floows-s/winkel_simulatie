package objects.stocker.states;

import core.Simulation;
import objects.graph.Vertex.VertexID;
import objects.path.Path;
import objects.shelf.ShelfManager;
import objects.stocker.Stocker;

public class DecideNextTask implements StockerState{

    Path pathToMiddleOfStockroom = null;

    @Override
    public void update(Stocker st, double delta, long now, Simulation s) {
        if(st.isHoldingBox()){
            st.setState(new UnpackHeldBox());
        }

        if(s.getTruck().isReadyToUnload()){
            st.setState(new UnloadTruck());
            return;
        }

        // Grab box to unpack and restock shelf
        VertexID shelfContainingBox = s.getShelfManager().getAccessPointOfStorageShelfWithBox();
        VertexID shelfThatNeedsRestocking = s.getShelfManager().getAccessPointOfShelfWichNeedRestocking();

        if(shelfContainingBox != null && shelfThatNeedsRestocking != null){
            st.setState(new GrabBoxFromShelf(shelfContainingBox));
            return;
        }

        // Else -> just wait...
        st.setSpriteToIdle();
        st.setState(new DecideNextTask());
    }
}
