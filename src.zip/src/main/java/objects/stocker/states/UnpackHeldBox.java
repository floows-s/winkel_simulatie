package objects.stocker.states;

import core.Simulation;
import core.logger.Logger;
import core.logger.TagLogger;
import objects.graph.Vertex.VertexID;
import objects.path.Path;
import objects.product.Product;
import objects.shelf.Shelf;
import objects.stocker.Stocker;

public class UnpackHeldBox implements StockerState {
    VertexID shelfAccessPoint = null;
    Path pathToShelf = null;

    Logger log = new TagLogger(getClass().getSimpleName());


    @Override
    public void update(Stocker st, double delta, long now, Simulation s) {
        if(!st.isHoldingBox()){
            log.logWarning("Attempted to unpack box while not holding one!");

            st.setState(new DecideNextTask());
            return;
        }

        // Get location of shelf which has room for products
        if(shelfAccessPoint == null){
            VertexID foundShelf = s.getShelfManager().getAccessPointOfShelfWichNeedRestocking();

            // No shelf to put box on, putting it back into stockroom
            if(foundShelf == null){
                st.setState(new PutHeldBoxIntoStockroom());
                return;
            }

            shelfAccessPoint = foundShelf;
        }

        // If at shelf
        if(st.getCurrentVertexID() == shelfAccessPoint){
            Shelf shelf = s.getShelfManager().get(shelfAccessPoint);

            // Shelf is full -> look for new shelf
            if(shelf.isFull()){
                st.setState(new UnpackHeldBox());
                return;
            }

            // Remove product from box
            Product p = st.getHeldBox().GetProduct();

            // Box is empty
            if(p == null){
                st.removeBox();
                st.setState(new DecideNextTask());
                System.out.println("BOX IS LEEG!!!!");
                return;
            }

            // Put product on shelf
            shelf.addItem(p);
            System.out.println("PRODUCT IS EINDELIJK TOEGEVOEGD!!!!");
            return;
        }

        // Walk to shelf
        if(pathToShelf == null){
            pathToShelf = s.getGraph().getShortestPath(st.getCurrentVertexID(), shelfAccessPoint);
        }
        st.followPath(pathToShelf, s.getGraph(), delta, now);
    }
}
